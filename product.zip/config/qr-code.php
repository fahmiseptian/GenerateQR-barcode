<?php

return [
    'default' => 'gd',
    'format' => 'png',
    'size' => 200,
    'error_correction' => 'H',
];
